﻿namespace SootAdventure
{
    public class Karakter
    {
        private int hp;
        private string name;
        private string level;
        public int HP { get; set; }
        public string Name { get; init; }
    }
}
