﻿// Mikuska Péter Marcell
// Hrubos Márk
// Pongrácz Gábor
// Bárdos Simon
// Szabó Szabolcs
// Farkas Botond
// <11.A>

#region Tutorial szoba

Console.WriteLine("Soot Adventure by - SmallPotHoles");

Console.WriteLine("Adja meg milyen nehézségen akarja játszni a játékot(könnyü/közepes/nehéz): ");
int difficultyy = int.Parse(Console.ReadLine()!);

Console.WriteLine("A játék során különböző betük beírásával tudsz majd válaszolni az adott kérdésekre és haladni a játékban.");

Console.WriteLine($"Jó szorakozást a játékhoz!");

#endregion

#region Mentés Rendszer

List<string> saves = File.ReadAllLines("Saves.txt").ToList(); // Ebben a fájlban vannak a különböző mentések nevei

Console.WriteLine("Mentések: ");

Console.WriteLine(String.Join("\n\t", saves));



bool complete = false;

do
{
    Console.WriteLine("Add meg a betölteni kivánt mentés nevét: ");
    string tempSave = Console.ReadLine()!;

    if (saves.Contains(tempSave))
    {
        string save = tempSave;
        Console.WriteLine($"{save} mentés betöltése");
        // Játék állás betöltve
        complete = true;
    }
    else
    {
        Console.WriteLine("Kérlek add meg egy létező mentés nevét!");
    }

} while (!complete);


#endregion
